//
// Created by manalipatil on 4/23/19.
//

#ifndef NS_3_ALLINONE_DIFF_SERV_H
#define NS_3_ALLINONE_DIFF_SERV_H

#include <queue>
#include "ns3/log.h"
#include "ns3/object-base.h"
#include "ns3/log-macros-disabled.h"
#include "ns3/packet.h"
#include "ns3/queue.h"
#include "ns3/traffic-class.h"
#include <vector>

namespace ns3{

    //class TraceContainer;
template <typename Item>
class Diffserv : public ns3::Queue<Item>{

    public:
    enum QueueMode
    {
        QUEUE_MODE_PACKETS,
        QUEUE_MODE_BYTES,
    };

        static TypeId GetTypeId(void);
        Diffserv();
        virtual ~Diffserv();

        void SetMode(Diffserv<Item>::QueueMode mode);

       // Diffserv::QueueMode GetMode(void); // have to make it const

        virtual Ptr<Item> Schedule(void);
        virtual bool Enqueue(Ptr<Item> item);
        virtual Ptr<Item> Dequeue(void);
        virtual Ptr<Item> Remove(void);
        virtual Ptr<const Item> Peek(void) const;

        std::vector<TrafficClass*> GetQ_Class(void);

        //Ptr<TrafficClass> GetTrafficClassAtIndex(int index);

        TrafficClass GetTrafficClassAtIndex(int index);

        uint32_t Classify(Ptr<Item> item);

    private:

        QueueMode m_mode;
        std::vector<TrafficClass*> q_class;
        bool DoEnqueue(Ptr<Item> item);
        virtual Ptr<Item> DoDequeue(void);
        virtual Ptr<const Item> DoPeek(void) const;

        NS_LOG_TEMPLATE_DECLARE;
    };

    template <typename Item>
    TypeId Diffserv<Item>::GetTypeId() {
        static TypeId tid = TypeId (("ns3::Diffserv<" + GetTypeParamName<Diffserv<Item>> () + ">").c_str ())
                                .SetParent<Queue<Item> > ()
                                .SetGroupName ("TrafficControl")
                                .template AddConstructor<Diffserv<Item> > ()
                                        ;
        return tid;
    }

    template <typename Item>
    Diffserv<Item>::Diffserv():Queue<Item>(),
    NS_LOG_TEMPLATE_DEFINE ("Diffserv")
    {
    }

    template <typename Item>
    Diffserv<Item>::~Diffserv(){
    }


    //template <typename Item>
    //Diffserv<Item>::QueueMode Diffserv<Item>::GetMode() {
    //    return m_mode;
    //}

    template <typename Item>
    void Diffserv<Item>::SetMode(ns3::Diffserv<Item>::QueueMode mode) {
        m_mode = mode;
    }

    template <typename Item>
    bool Diffserv<Item>::Enqueue(Ptr <Item> item) {
        return Enqueue(item);
    }

    template <typename Item>
    Ptr<Item> Diffserv<Item>::Dequeue() {
        return Dequeue();
    }

    template <typename Item>
    Ptr<Item> Diffserv<Item>::Remove() {
        return Remove();
    }

    template <typename Item>
    Ptr<const Item> Diffserv<Item>::Peek() const {
        return Peek();
    }

   template <typename Item>
   std::vector<TrafficClass *> Diffserv<Item>::GetQ_Class() {
       return this->q_class;
   }

   template <typename Item>
   uint32_t Diffserv<Item>::Classify(Ptr <Item> item) {
       int i = 0;
       for(TrafficClass* trafficClass: q_class) {
           i = i+1;
           if (trafficClass->Match(item)) {
               return i;
           }
       }
       return 0;
   }

   template <typename Item>
   bool Diffserv<Item>::DoEnqueue(Ptr <Item> item) {
       bool resultOfEnqueue = false;
       uint32_t i = Classify(item);
       TrafficClass tc = GetTrafficClassAtIndex(int(i));
       resultOfEnqueue = tc.Enqueue(item);
       return resultOfEnqueue;
   }

   template <typename Item>
   TrafficClass Diffserv<Item>::GetTrafficClassAtIndex(int index) {
       TrafficClass* tc;
       tc = q_class[index];
       return *tc ;
   }

   //todo
   template <typename Item>
   Ptr<Item> Diffserv<Item>::DoDequeue() {
       Ptr<Item> p = new Packet();
       return p;
   }

   //todo
   template <typename Item>
   Ptr<const Item> Diffserv<Item>::DoPeek() const {
       Ptr<Item> p = new Packet();
       return p;
   }

   //todo
   template <typename Item>
   Ptr<Item> Diffserv<Item>::Schedule() {
       Ptr<Item> p = new Packet();
       return p;
   }
   extern template class Diffserv<Packet>;
}
#endif //NS_3_ALLINONE_DIFF_SERV_H