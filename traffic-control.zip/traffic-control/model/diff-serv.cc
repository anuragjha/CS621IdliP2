//
// Created by manalipatil on 4/23/19.
//
#include "ns3/log.h"
#include "ns3/object-base.h"
#include "ns3/log-macros-disabled.h"
#include "diff-serv.h"

namespace ns3 {
    NS_LOG_COMPONENT_DEFINE("Diffserv");

    NS_OBJECT_TEMPLATE_CLASS_DEFINE (Diffserv,Packet);
}