//
// Created by manalipatil on 4/23/19.
//

#include "ns3/log.h"
#include "ns3/log-macros-enabled.h"
#include "ns3/log-macros-disabled.h"
#include "diff-serv.h"
#include "ns3/packet.h"
#include <cstring>
#include <iostream>
#include <vector>
#include "ns3/object.h"
#include "ns3/uinteger.h"
#include "spq.h"

namespace ns3{
    NS_LOG_COMPONENT_DEFINE("SPQ");

    NS_OBJECT_ENSURE_REGISTERED(SPQ);

    TypeId SPQ::GetTypeId(void) {
        static TypeId tid = TypeId("ns3::SPQ")
                .SetParent<Diffserv>()
                .SetGroupName("TrafficControl");
        return tid;
    }

    SPQ::SPQ(){
        //NS_LOG_FUNCTION(this);//we
    }

    SPQ::~SPQ() {
        //NS_LOG_FUNCTION(this);//we
    }

    //todo
    bool SPQ::DoEnqueue(Ptr <Packet> packet) {
       // NS_LOG_FUNCTION(this);//we
       return true;
    }

    //todo
    Ptr<Packet> SPQ::DoDequeue() {
        Ptr<Packet> p = new Packet();
        return p;
    }

    //todo
    Ptr<const Packet> SPQ::DoPeek() {
        Ptr<Packet> p = new Packet();
        return p;
    }
}