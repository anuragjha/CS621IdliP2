//
// Created by manalipatil on 4/22/19.
//
#include "ns3/log.h"
#include "ns3/packet.h"
#include "filter-element.h"
#include "filter.h"

namespace ns3{

    NS_LOG_COMPONENT_DEFINE("Filter");
    NS_OBJECT_ENSURE_REGISTERED(Filter);

    TypeId Filter::GetTypeId() {
        static TypeId tid = TypeId ("ns3::Filter")
                .SetParent<Object> ()
                .SetGroupName ("TrafficControl")
        ;
        return tid;
    }

    Filter::Filter(){
      //  NS_LOG_FUNCTION(this);
    }

    Filter::~Filter(){
      //  NS_LOG_fUNCTION(this);
    }

    bool Filter::Match(Ptr<ns3::Packet> packet){

        for(FilterElement* filterElement:filterElements){

            if(filterElement->Match(packet)){
                return true;
            }

       // auto iter = filterElements.begin();
       // for(;iter != filterElements.end();iter++){
       //     if ((iter**).Match(packet) == false){
        //        return false;
        //    }
        }
        return false;
    }
}