//
// Created by manalipatil on 4/23/19.
//

#ifndef NS_3_ALLINONE_TRAFFIC_CLASS_H
#define NS_3_ALLINONE_TRAFFIC_CLASS_H
#include <vector>
#include <queue>
#include "ns3/object.h"
#include "ns3/log.h"
#include "ns3/integer.h"
#include "ns3/pointer.h"
#include "filter.h"
#include "ns3/packet.h"
#include "ns3/ptr.h"
#include "ns3/uinteger.h"

namespace ns3 {

    //class TrafficClass;

/**
 * \ingroup traffic-control
 *
 * PacketFilter is the abstract base class for filters used by queue discs
 * to classify packets.
 */
    class TrafficClass: public Object {
    public:
        /**
         * \brief Get the type ID.
         * \return the object TypeId
         */
        static TypeId GetTypeId (void);

        TrafficClass ();
        ~TrafficClass ();

        bool IfEmpty();
        bool Enqueue(Ptr<ns3::Packet> packet);

        bool Match(Ptr<ns3::Packet> packet);

        uint32_t GetQueueSize(void);

        Ptr<ns3::Packet> Dequeue(void);

        /**
         * \brief Classify a packet.
         *
         * \param item the packet to classify.
         *
         * \return -1 if this filter is not able to classify packets of the same protocol
         * as item or the item does not match the filter conditions, the configured return
         * value otherwise.
         */
        // int32_t Classify (Ptr<QueueDiscItem> item) const;

    private:

        std::vector<Filter*> filters;
        uint32_t bytes;
        double weight;
        uint32_t packets;
        uint32_t maxPackets;
        uint32_t maxBytes;
        uint32_t priority_level;
        bool isDefault;
        std::queue<Ptr<Packet>> m_queue;
    };
} // namespace ns3
#endif //NS_3_ALLINONE_TRAFFIC_CLASS_H
